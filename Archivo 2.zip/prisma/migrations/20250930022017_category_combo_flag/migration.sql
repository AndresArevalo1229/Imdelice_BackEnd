-- AlterTable
ALTER TABLE `Category` ADD COLUMN `isComboOnly` BOOLEAN NOT NULL DEFAULT false;
