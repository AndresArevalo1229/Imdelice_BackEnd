-- AlterTable
ALTER TABLE `Payment` ADD COLUMN `changeCents` INTEGER NULL,
    ADD COLUMN `receivedAmountCents` INTEGER NULL;
