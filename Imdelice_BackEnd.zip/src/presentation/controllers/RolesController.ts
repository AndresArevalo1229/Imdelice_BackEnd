import { Request, Response } from "express";
import { success, fail } from "../utils/apiResponse";
import { CreateRole } from "../../core/usecases/roles/CreateRole";
import { UpdateRole } from "../../core/usecases/roles/UpdateRole";
import { DeleteRole } from "../../core/usecases/roles/DeleteRole";
import { GetRoleById } from "../../core/usecases/roles/GetRoleById";
import { ListRoles } from "../../core/usecases/roles/ListRoles";
import { CreateRoleDto, UpdateRoleDto } from "../dtos/roles.dto";
import { SetRolePermissions } from '../../core/usecases/roles/SetRolePermissions'

export class RolesController {
  constructor(
    private listRoles: ListRoles,
    private getRoleById: GetRoleById,
    private createRole: CreateRole,
    private updateRole: UpdateRole,
    private deleteRole: DeleteRole,
        private setRolePerms: SetRolePermissions // 👈 inyecta por container

  ) {}

  list = async (_: Request, res: Response) => {
    const roles = await this.listRoles.execute();
    return success(res, roles, "Roles obtenidos");
  };

  get = async (req: Request, res: Response) => {
    const id = Number(req.params.id);
    if (Number.isNaN(id)) return fail(res, "ID inválido", 400);

    const role = await this.getRoleById.execute(id);
    if (!role) return fail(res, "Rol no encontrado", 404);
    return success(res, role, "Rol encontrado");
  };

  create = async (req: Request, res: Response) => {
    const parsed = CreateRoleDto.safeParse(req.body)
    if (!parsed.success) return fail(res, "Datos inválidos", 400, parsed.error.format())
    const role = await this.createRole.execute({ name: parsed.data.name, description: parsed.data.description ?? null })
    if (parsed.data.permissionCodes?.length) {
      await this.setRolePerms.execute(role.id, parsed.data.permissionCodes)
    }
    const out = await this.getRoleById.execute(role.id)
    return success(res, out, "Rol creado")
  }

  update = async (req: Request, res: Response) => {
    const id = Number(req.params.id)
    const parsed = UpdateRoleDto.safeParse(req.body)
    if (!parsed.success) return fail(res, "Datos inválidos", 400, parsed.error.format())
    const updated = await this.updateRole.execute({ id, ...parsed.data })
    if (parsed.data.permissionCodes) {
      await this.setRolePerms.execute(id, parsed.data.permissionCodes)
    }
    const out = await this.getRoleById.execute(id)
    return success(res, out, "Rol actualizado")
  }


  delete = async (req: Request, res: Response) => {
    const id = Number(req.params.id);
    if (Number.isNaN(id)) return fail(res, "ID inválido", 400);

    await this.deleteRole.execute(id);
    return success(res, { id }, "Rol eliminado");
  };
}
