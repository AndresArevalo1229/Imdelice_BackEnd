-- DropIndex
DROP INDEX `User_pinCodeHash_key` ON `User`;
